# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pymongo.errors import PyMongoError

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    # updated the constructor to accept a username and password instead of writing them directly in the code
    def __init__(self, username, password):
        USER = username
        PASS = password
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        # Added input validation (isinstance and len>0) and switched to PyMongoError based on professor feedback
        if data is not None and isinstance(data, dict) and len(data) > 0: 
            try:
                # changed from self.database.animals to self.collection since I already set up self.collection in init as a shortcut to the animals collection
                self.collection.insert_one(data)  # data should be dictionary      
            
                # changed to true/false
                return True
            except PyMongoError: 
                return False
        else:
            return False

    # Updated to add None check so passing None doesn't return everything in the database. Added try/except to handle errors without crashing. Changed to self.collection to use the shortcut from init. Added docstring to explain what the method does. 
    def read(self, data):
        """Searches the animals collection using the given filter. Then returns a list of matching animal records, or an empty list if no matches are found or an error happens."""
        if data is None:
            return []
        try:
            return list(self.collection.find(data))
        except PyMongoError:
            return []
        
    # 
    def update(self, lookup, update_data):
        """Updates documents in the animals collection that match the lookup filter. Then returns how many documents were changed."""
        if lookup is None or update_data is None: 
            return 0
        try:
            result = self.collection.update_many(lookup, update_data)
            return result.modified_count
        except PyMongoError:
            return 0
    
    # deletes matching documents from the collection. Then returns the number deleted. 
    def delete(self, lookup):
        if lookup is None:
            return 0
        try:
            result = self.collection.delete_many(lookup)
            return result.deleted_count
        except PyMongoError:
            return 0